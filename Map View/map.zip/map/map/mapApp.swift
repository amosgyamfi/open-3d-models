//
//  mapApp.swift
//  map
//
//  Created by Amos Gyamfi on 1.8.2020.
//

import SwiftUI

@main
struct mapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
