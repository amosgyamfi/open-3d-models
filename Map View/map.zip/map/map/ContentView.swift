//
//  ContentView.swift
//  map
//
//  Created by Amos Gyamfi on 1.8.2020.
//

import SwiftUI
import MapKit

struct ContentView: View {
    @State private var currentLocation =
        MKCoordinateRegion( center: CLLocationCoordinate2D(
            latitude: 60.5300, // Get current location's latitude from Google
            longitude: 24.9051), // Get current location's longititude from Google
            span: MKCoordinateSpan(
                latitudeDelta: 0.5, //North and south locations nearby. The amount of north-to-south distance (measured in degrees) to display for the map region.
                longitudeDelta: 0.5)) //East and west locations nearby. The amount of east-to-west distance (measured in degrees) to display for the map region.
    var body: some View {
        ZStack {
            Map(coordinateRegion: $currentLocation)
        }
        .frame(width: 392, height: 119, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
        .cornerRadius(24)
        .hueRotation(.degrees(0))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(/*@START_MENU_TOKEN@*/.dark/*@END_MENU_TOKEN@*/)
    }
}
