//
//  wiggleApp.swift
//  wiggle
//
//  Created by Amos Gyamfi on 6.8.2020.
//

import SwiftUI

@main
struct wiggleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}



