//
//  WeatherView.swift
//  wiggle
//
//  Created by Amos Gyamfi on 6.8.2020.
//

import Foundation
import SwiftUI

struct WeatherView: View {
    
    @State private var weatherWiggles = false
    
    let weatherBg = LinearGradient(gradient: Gradient(colors: [Color.blue, Color.white]), startPoint: .topLeading, endPoint: .bottomTrailing)
    
    var body: some View {
        ZStack { // Weather
            
            VStack(alignment: .leading) {
                Text("Wednesday")
                
                Text("18°")
                    .font(.system(size: 44))
                    .fontWeight(.thin)
                
                Spacer()
                Image(systemName: "cloud.sun.fill")
                Text("Partly Cloudy")
                    .frame(width: 150, height: 20, alignment: .leading)
                Text("H:21° L:12°")
                    
            }
            .padding()
            .background(weatherBg)
            .cornerRadius(22)
            .foregroundColor(.white)
            
        }.frame(width: 170, height: 170, alignment: .leading)
        .overlay(Image(systemName: "minus.circle.fill")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .foregroundColor(Color(.systemGray))
                    .offset(x: -80, y: -80))
        .rotationEffect(.degrees(weatherWiggles ? 2.5 : 0))
        .animation(Animation.easeInOut(duration: 0.15).repeatForever(autoreverses: true))
        .onAppear() {
            weatherWiggles.toggle()
        }

    }
}





