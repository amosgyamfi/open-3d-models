//
//  ContentView.swift
//  Showing and hiding overflow/secondary content with DIsclosureGroup
//
//  Created by Amos Gyamfi on 1.8.2020.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Privacy FAQ")
                .font(.largeTitle)
            
            List{
                DisclosureGroup("How do you protect users?") {
                    Text("Downloading documents require authentication. So you will need to register to get access to all documents")
                }
                
                DisclosureGroup("What data is collected?") {
                    Text("Downloading documents require authentication. So you will need to register to get access to all documents")
                }
                
                DisclosureGroup("What hapends with my data?") {
                    Text("Downloading documents require authentication. So you will need to register to get access to all documents")
                }
                
                DisclosureGroup("How is the settings adjusted?") {
                    Text("Downloading documents require authentication. So you will need to register to get access to all documents")
                }
                
                DisclosureGroup("Where do I find the privacy?") {
                    Text("Downloading documents require authentication. So you will need to register to get access to all documents")
                }
            }.listStyle(InsetGroupedListStyle()).padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/, /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
        }.padding(.horizontal, 20)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}
