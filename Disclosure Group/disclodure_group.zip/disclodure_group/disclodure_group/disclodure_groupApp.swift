//
//  disclodure_groupApp.swift
//  disclodure_group
//
//  Created by Amos Gyamfi on 1.8.2020.
//

import SwiftUI

@main
struct disclodure_groupApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
