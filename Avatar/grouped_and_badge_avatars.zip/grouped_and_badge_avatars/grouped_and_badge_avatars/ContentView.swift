//
//  ContentView.swift
//  grouped_and_badge_avatars
//
//  Created by Amos Gyamfi on 23.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State private var isPulsing = false
    
    var body: some View {
        VStack(alignment: .center, spacing: 50) {
            Text("Grouped & Badge Avatars")
                .font(.title)
            
            // Grouped
            HStack(alignment: .center, spacing: -15) {
                Image("avatar1")
                    
                Image("avatar2")
                    .overlay(Circle().stroke(lineWidth: 2).foregroundColor(.white))
                Image("avatar3")
                    .overlay(Circle().stroke(lineWidth: 2).foregroundColor(.white))
                Circle()
                    .frame(width: 70, height: 70)
                    .foregroundColor(Color(#colorLiteral(red: 0.9568627451, green: 0.9490196078, blue: 0.9450980392, alpha: 1)))
                    .overlay(Circle().stroke(lineWidth: 2).foregroundColor(.white))
                    .overlay(Text("+2").font(.title).foregroundColor(.white))
            }
            
            // Badge
            HStack {
                HStack(alignment: .bottom, spacing: -15) {
                    Image("avatar1")
                    ZStack {
                        Circle()
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(#colorLiteral(red: 0, green: 0, blue: 0.6274509804, alpha: 1)))
                            .overlay(Circle().stroke(lineWidth: 2).foregroundColor(.white))
                            
                        Circle()  // Animate Stroke
                            .stroke(lineWidth: 2)
                            .frame(width: 20, height: 20)
                            .foregroundColor(Color(#colorLiteral(red: 0, green: 0, blue: 0.6274509804, alpha: 1)))
                            .scaleEffect(isPulsing ? 1.5 : 0)
                            .opacity(isPulsing ? 0 : 1)
                            .animation(Animation.easeInOut(duration: 2).delay(1).repeatForever(autoreverses: false))
                            .onAppear() {
                                        self.isPulsing.toggle()
                                }
                    }
                }
                    
                HStack(alignment: .bottom, spacing: -19) {
                    Image("avatar2")
                        .overlay(Circle().stroke(lineWidth: 2).foregroundColor(.white))
                    
                    Image("avatar1")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .overlay(Circle().stroke(lineWidth: 2).foregroundColor(.white))
                }
               
                
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
