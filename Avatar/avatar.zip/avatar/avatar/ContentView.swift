//
//  ContentView.swift
//  SwiftUI Avatars: Suitable for use in tables and dialog menus.
//
//  Created by Amos Gyamfi on 22.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Initials and Images Avatars")
                .font(.title)
                .foregroundColor(Color(#colorLiteral(red: 0.2605174184, green: 0.2605243921, blue: 0.260520637, alpha: 1)))
            HStack {
                VStack {
                    Circle()
                        .frame(width: 70, height: 70)
                        .foregroundColor(Color(#colorLiteral(red: 0.5137254902, green: 0.7215686275, blue: 0.9294117647, alpha: 1)))
                        .overlay(Text("XX").foregroundColor(.white))
                    
                    Circle()
                        .frame(width: 40, height: 40)
                        .foregroundColor(Color(#colorLiteral(red: 0.5137254902, green: 0.7215686275, blue: 0.9294117647, alpha: 1)))
                        .overlay(Text("XL").foregroundColor(.white))
                    
                    Circle()
                        .frame(width: 35, height: 35)
                        .foregroundColor(Color(#colorLiteral(red: 0.5137254902, green: 0.7215686275, blue: 0.9294117647, alpha: 1)))
                        .overlay(Text("L").foregroundColor(.white))
                    
                    Circle()
                        .frame(width: 30, height: 30)
                        .foregroundColor(Color(#colorLiteral(red: 0.5137254902, green: 0.7215686275, blue: 0.9294117647, alpha: 1)))
                        .overlay(Text("M").foregroundColor(.white))
                    
                    Circle()
                        .frame(width: 25, height: 25)
                        .foregroundColor(Color(#colorLiteral(red: 0.5137254902, green: 0.7215686275, blue: 0.9294117647, alpha: 1)))
                        .overlay(Text("S").foregroundColor(.white))
                    
                    Circle()
                        .frame(width: 20, height: 20)
                        .foregroundColor(Color(#colorLiteral(red: 0.5137254902, green: 0.7215686275, blue: 0.9294117647, alpha: 1)))
                        .overlay(Text("XS").font(.caption).foregroundColor(.white))
                }
                
                VStack {
                    HStack {
                        Image("amos")
                            .resizable()
                            .frame(width: 70, height: 70)
                        
                    }
                    
                    Image("amos")
                        .resizable()
                        .frame(width: 40, height: 40)
                    
                    Image("amos")
                        .resizable()
                        .frame(width: 35, height: 35)
                    
                    Image("amos")
                        .resizable()
                        .frame(width: 30, height: 30)
                    
                    Image("amos")
                        .resizable()
                        .frame(width: 25, height: 25)
                    
                    Image("amos")
                        .resizable()
                        .frame(width: 20, height: 20)
                }
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
