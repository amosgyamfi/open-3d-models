//
//  ContentView.swift
//  SwiftUI Multiline Text Editor
//
//  Created by Amos Gyamfi on 24.7.2020.
//

import SwiftUI

struct ContentView: View {
    @State private var fieldPlaceholder = "Enter your multiline text here!!!"
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Multiline Text")
            TextEditor(text: $fieldPlaceholder)
                .frame(width: 300, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                .background(Color(.systemGray))
                .border(Color(.systemGray5), width: 2)
                .cornerRadius(2)
                .shadow(color: .gray, radius: 1, x: 1, y: 1)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
