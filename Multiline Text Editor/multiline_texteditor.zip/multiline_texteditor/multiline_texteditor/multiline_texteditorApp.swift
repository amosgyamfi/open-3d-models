//
//  multiline_texteditorApp.swift
//  multiline_texteditor
//
//  Created by Amos Gyamfi on 24.7.2020.
//

import SwiftUI

@main
struct multiline_texteditorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
