//
//  ContentView.swift
//  textfield
//
//  Created by Amos Gyamfi on 24.7.2020.
//

import SwiftUI

struct ContentView: View {
    
    @State private var fieldPlaceholder = ""
    let screenFrame = LinearGradient(gradient: Gradient(colors: [Color(#colorLiteral(red: 0.4620226622, green: 0.8382837176, blue: 1, alpha: 1)), Color(#colorLiteral(red: 0.476841867, green: 0.5048075914, blue: 1, alpha: 1))]), startPoint: /*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/, endPoint: .bottomTrailing)
    var body: some View {
        ZStack {
            
            screenFrame
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            VStack(alignment: .leading) {
                Text("Email")
                    .font(.caption)
                TextField("youremail@gmail.com", text: $fieldPlaceholder)
                    .font(.caption2)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 300, height: 46, alignment: .leading)
                    .foregroundColor(Color(.systemGray))
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
           
    }
}
