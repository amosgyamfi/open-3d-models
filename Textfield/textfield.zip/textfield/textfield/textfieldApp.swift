//
//  textfieldApp.swift
//  textfield
//
//  Created by Amos Gyamfi on 24.7.2020.
//

import SwiftUI

@main
struct textfieldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
