//
//  dateIntervalApp.swift
//  dateInterval
//
//  Created by Amos Gyamfi on 2.8.2020.
//

import SwiftUI

@main
struct dateIntervalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
